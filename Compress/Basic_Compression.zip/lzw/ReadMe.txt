%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                         %
%            lzw compression   Read Me                    %
%                                                         %
%                                                         %
% Last update: 11 may 2004                                %
% by Pepecito, pepecito@email.it                          %
%                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

###################################
#                                 #
#     Content of ZIP archive      #
#                                 #
###################################

1. norm2lzw.m      (encoder function)
2. lzw2norm.m      (decoder function)
3. lzw_demo1.m     (demo file)
4. lzw_docs.zip    (documentation)
5. Disclamer.txt   (this is the disclamer)
6. ReadMe.txt      (this file)


###################################
#                                 #
#             NOTES               #
#                                 #
###################################

The function has been created using the following Matlab version:

>> version

ans =

6.1.0.450 (R12.1)